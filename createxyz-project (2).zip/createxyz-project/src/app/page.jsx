"use client";
import React from "react";
import * as ChakraUI from "@chakra-ui/react";
import * as ShadcnUI from "@/design-libraries/shadcn-ui";
import { useHandleStreamResponse } from "../utilities/runtime-helpers";

function MainComponent() {
  const [messages, setMessages] = useState([]);
  const [inputMessage, setInputMessage] = useState("");
  const [streamingMessage, setStreamingMessage] = useState("");
  const [counselor, setCounselor] = useState(null);
  const messagesEndRef = useRef(null);
  const [boxColor, setBoxColor] = useState("#f0f9ff");
  const [keyboardVisible, setKeyboardVisible] = useState(false);
  const [showPetals, setShowPetals] = useState(false);
  const [showCreatorInfo, setShowCreatorInfo] = useState(false);
  const [showRating, setShowRating] = useState(false);
  const [userRating, setUserRating] = useState(null);
  const [score, setScore] = useState(0);
  const [showQuiz, setShowQuiz] = useState(false);
  const [currentQuiz, setCurrentQuiz] = useState(null);
  const [quizStreak, setQuizStreak] = useState(0);
  const [showBadge, setShowBadge] = useState(false);
  const [lastMessageRef, setLastMessageRef] = useState(null);
  const [isMessagesVisible, setIsMessagesVisible] = useState(true);
  const [showHearts, setShowHearts] = useState(false);
  const [isTranslating, setIsTranslating] = useState(false);
  const [showCuteGif, setShowCuteGif] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [lastMessageTime, setLastMessageTime] = useState(Date.now());
  const [showReminder, setShowReminder] = useState(false);
  const [isDarkMode, setIsDarkMode] = useState(false);
  const [showEmotions, setShowEmotions] = useState(false);
  const emotions = [
    { emoji: "😊", label: "Vui vẻ" },
    { emoji: "😢", label: "Buồn bã" },
    { emoji: "😰", label: "Lo lắng" },
    { emoji: "🤗", label: "Hào hứng" },
    { emoji: "😴", label: "Mệt mỏi" },
    { emoji: "😡", label: "Tức giận" },
    { emoji: "🤔", label: "Băn khoăn" },
    { emoji: "😌", label: "Nhẹ nhõm" },
  ];

  const counselors = [
    {
      name: "Thầy Đinh Trung Kiên",
      image: "/counselor1.jpg",
      prefix: "Thầy",
      subject: "Toán",
      role: "Hiệu trưởng",
    },
    {
      name: "Cô Nguyễn Thị Thủy",
      image: "/counselor2.jpg",
      prefix: "Cô",
      subject: "Toán",
    },
    {
      name: "Thầy Trần Kim Quy",
      image: "/counselor3.jpg",
      prefix: "Thầy",
      subject: "Toán",
    },
    {
      name: "Cô Hà Thị Thúy Vân",
      image: "/counselor4.jpg",
      prefix: "Cô",
      subject: "Toán",
    },
    {
      name: "Cô Hoàng Thị Khuế",
      image: "/counselor5.jpg",
      prefix: "Cô",
      subject: "Toán",
    },
    {
      name: "Thầy Đỗ Ngọc Huỳnh",
      image: "/counselor6.jpg",
      prefix: "Thầy",
      subject: "Ngữ văn",
      role: "Hiệu phó",
    },
    {
      name: "Cô Nguyễn Thị Huế",
      image: "/counselor7.jpg",
      prefix: "Cô",
      subject: "Ngữ văn",
    },
    {
      name: "Cô Nguyễn Thị Kim Hương",
      image: "/counselor8.jpg",
      prefix: "Cô",
      subject: "Ngữ văn",
    },
    {
      name: "Thầy Nguyễn Ngọc Khanh",
      image: "/counselor9.jpg",
      prefix: "Thầy",
      subject: "Ngữ văn",
    },
    {
      name: "Cô Hoàng Thị Khánh",
      image: "/counselor10.jpg",
      prefix: "Cô",
      subject: "Ngữ văn",
    },
    {
      name: "Thầy Nguyễn Xuân Thủy",
      image: "/counselor11.jpg",
      prefix: "Thầy",
      subject: "Tiếng Anh",
    },
    {
      name: "Cô Lành Thị Luyến",
      image: "/counselor12.jpg",
      prefix: "Cô",
      subject: "Tiếng Anh",
    },
    {
      name: "Cô Hà Thị Thúy Hường",
      image: "/counselor13.jpg",
      prefix: "Cô",
      subject: "Tiếng Anh",
    },
    {
      name: "Thầy Tạ Quốc Hưng",
      image: "/counselor14.jpg",
      prefix: "Thầy",
      subject: "Sinh học",
    },
    {
      name: "Thầy Mùa A Đàng",
      image: "/counselor15.jpg",
      prefix: "Thầy",
      subject: "Sinh học",
    },
    {
      name: "Cô Phan Thị Thanh",
      image: "/counselor16.jpg",
      prefix: "Cô",
      subject: "Sinh học",
    },
    {
      name: "Cô Phạm Thị Hạnh",
      image: "/counselor17.jpg",
      prefix: "Cô",
      subject: "Tin học",
    },
    {
      name: "Thầy Nguyễn Minh Tâm",
      image: "/counselor18.jpg",
      prefix: "Thầy",
      subject: "Tin học",
    },
    {
      name: "Thầy Nguyễn Văn Ly",
      image: "/counselor19.jpg",
      prefix: "Thầy",
      subject: "Hóa học",
    },
    {
      name: "Thầy Duy Công Hạnh",
      image: "/counselor20.jpg",
      prefix: "Thầy",
      subject: "Vật lí",
      info: {
        birthYear: "1994",
        maritalStatus: "chưa có vợ",
        hobbies: ["thể thao", "âm nhạc", "hội họa"],
        phone: "0868640898",
      },
    },
    {
      name: "Thầy Nguyễn Tiến Dũng",
      image: "/counselor21.jpg",
      prefix: "Thầy",
      subject: "Vật lí",
      info: {
        birthYear: "1992",
        maritalStatus: "mới lấy vợ",
      },
    },
    {
      name: "Cô Phạm Thị Thu Hà",
      image: "/counselor22.jpg",
      prefix: "Cô",
      subject: "Lịch sử",
    },
    {
      name: "Thầy Lê Văn Vĩnh",
      image: "/counselor23.jpg",
      prefix: "Thầy",
      subject: "Lịch sử",
    },
    {
      name: "Thầy Nguyễn Duy Thể",
      image: "/counselor24.jpg",
      prefix: "Thầy",
      subject: "Địa lí",
    },
    {
      name: "Cô Đặng Thị Lan Phương",
      image: "/counselor25.jpg",
      prefix: "Cô",
      subject: "Địa lí",
    },
    {
      name: "Cô Nguyễn Thị Điệp Quỳnh",
      image: "/counselor26.jpg",
      prefix: "Cô",
      subject: "GDCD",
    },
    {
      name: "Thầy Nguyễn Quốc Minh",
      image: "/counselor27.jpg",
      prefix: "Thầy",
      subject: "Công nghệ",
    },
    {
      name: "Cô Lê Kim Dung",
      image: "/counselor28.jpg",
      prefix: "Cô",
      subject: "Công nghệ",
    },
    {
      name: "Cô Lê Thị Thu",
      image: "/counselor29.jpg",
      prefix: "Cô",
      subject: "Công nghệ",
    },
    {
      name: "Cô Nguyễn Thị Bích Nguyệt",
      image: "/counselor30.jpg",
      prefix: "Cô",
      subject: "GD Thể chất",
    },
    {
      name: "Thầy Đinh Minh Hoạt",
      image: "/counselor31.jpg",
      prefix: "Thầy",
      subject: "GD Thể chất",
    },
    {
      name: "Cô Đinh Thị Thu Hiền",
      image: "/counselor32.jpg",
      prefix: "Cô",
      subject: "Âm nhạc",
    },
    {
      name: "Thầy Trần Trọng Nam",
      image: "/counselor33.jpg",
      prefix: "Thầy",
      subject: "Mỹ thuật",
    },
  ];

  const quizzes = [
    {
      question:
        "Khi gặp khó khăn trong học tập, điều đầu tiên bạn nên làm là gì?",
      options: [
        "Bỏ cuộc và chơi game",
        "Tìm hiểu nguyên nhân khó khăn",
        "Chép bài của bạn",
        "Không làm gì cả",
      ],
      correct: 1,
      explanation:
        "Tìm hiểu nguyên nhân khó khăn giúp bạn giải quyết vấn đề hiệu quả hơn!",
    },
    {
      question: "Làm thế nào để cải thiện kỹ năng giao tiếp?",
      options: [
        "Tránh nói chuyện với mọi người",
        "Luyện tập nói trước gương",
        "Chỉ nói chuyện online",
        "Chờ người khác bắt chuyện trước",
      ],
      correct: 1,
      explanation:
        "Luyện tập thường xuyên giúp bạn tự tin hơn trong giao tiếp!",
    },
  ];

  const handleQuizAnswer = (answerIndex) => {
    if (currentQuiz.correct === answerIndex) {
      setScore((prev) => prev + 10);
      setQuizStreak((prev) => prev + 1);
      if (quizStreak + 1 >= 3) {
        setShowBadge(true);
        setTimeout(() => setShowBadge(false), 3000);
      }
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: `🎉 Chính xác! +10 điểm\n${currentQuiz.explanation}`,
        },
      ]);
    } else {
      setQuizStreak(0);
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: `❌ Chưa đúng rồi. Hãy thử lại nhé!\n${currentQuiz.explanation}`,
        },
      ]);
    }
    setShowQuiz(false);
  };

  const startQuiz = () => {
    const randomQuiz = quizzes[Math.floor(Math.random() * quizzes.length)];
    setCurrentQuiz(randomQuiz);
    setShowQuiz(true);
  };

  useEffect(() => {
    const quizInterval = setInterval(() => {
      if (messages.length > 0 && !showQuiz) {
        startQuiz();
      }
    }, 300000);
    return () => clearInterval(quizInterval);
  }, [messages.length, showQuiz]);

  const censorBadWords = (text) => {
    const badWords = [
      "chém",
      "xẻ thịt",
      "tàn phá",
      "hủy diệt",
      "nổ tung",
      "tra tấn",
      "dọa dẫm",
      "tao sẽ",
      "mày sẽ biết tay",
      "hãy đợi đấy",
      "ngu",
      "đần",
      "khùng",
      "khốn nạn",
      "đồ điên",
      "dốt",
      "bẩn",
      "đểu",
      "lố bịch",
      "tào lao",
      "mất dạy",
      "chó",
      "đĩ",
      "lừa đảo",
      "dối trá",
      "đểu cáng",
      "thảm hại",
      "thối tha",
      "mày chẳng là cái gì cả",
      "đồ vô dụng",
      "đụ",
      "địt",
      "lồn",
      "cặc",
      "buồi",
      "đéo",
      "đít",
      "đm",
      "clm",
      "cc",
      "cl",
      "dcm",
      "đcm",
      "vl",
      "vcl",
      "đkm",
    ];
    let censoredText = text.toLowerCase();
    badWords.forEach((word) => {
      const regex = new RegExp(word, "gi");
      censoredText = censoredText.replace(regex, "***");
    });
    return censoredText;
  };

  const detectSubject = (message) => {
    const subjects = {
      toán: {
        keywords: [
          "toán",
          "toan",
          "math",
          "số học",
          "đại số",
          "hình học",
          "phương trình",
        ],
        name: "Toán",
      },
      văn: {
        keywords: [
          "văn",
          "van",
          "ngữ văn",
          "ngu van",
          "literature",
          "làm văn",
          "tập làm văn",
        ],
        name: "Ngữ văn",
      },
      anh: {
        keywords: [
          "anh",
          "tiếng anh",
          "english",
          "eng",
          "vocabulary",
          "grammar",
        ],
        name: "Tiếng Anh",
      },
      sinh: {
        keywords: ["sinh", "sinh học", "biology", "sinh vật"],
        name: "Sinh học",
      },
      tin: {
        keywords: [
          "tin",
          "tin học",
          "máy tính",
          "computer",
          "informatics",
          "công nghệ thông tin",
        ],
        name: "Tin học",
      },
      hóa: {
        keywords: ["hóa", "hoa hoc", "hóa học", "chemistry"],
        name: "Hóa học",
      },
      lý: {
        keywords: ["lý", "vật lý", "vat ly", "physics"],
        name: "Vật lí",
      },
      sử: {
        keywords: ["sử", "lịch sử", "lich su", "history"],
        name: "Lịch sử",
      },
      địa: {
        keywords: ["địa chỉ", "môn địa lí", "địa lý", "dia ly", "geography"],
        name: "Địa lí",
      },
      gdcd: {
        keywords: ["gdcd", "giáo dục công dân", "công dân", "đạo đức"],
        name: "GDCD",
      },
      "công nghệ": {
        keywords: ["công nghệ", "cong nghe", "kỹ thuật", "technology"],
        name: "Công nghệ",
      },
      "thể dục": {
        keywords: ["thể dục", "thể thao", "thể chất", "physical", "thể lực"],
        name: "GD Thể chất",
      },
      nhạc: {
        keywords: ["nhạc", "âm nhạc", "music", "hát"],
        name: "Âm nhạc",
      },
      "mỹ thuật": {
        keywords: ["mỹ thuật", "vẽ", "hội họa", "art"],
        name: "Mỹ thuật",
      },
    };

    const lowerMessage = message.toLowerCase();
    for (const subject of Object.values(subjects)) {
      if (subject.keywords.some((keyword) => lowerMessage.includes(keyword))) {
        return subject.name;
      }
    }
    return null;
  };

  useEffect(() => {
    const randomCounselor =
      counselors[Math.floor(Math.random() * counselors.length)];
    setCounselor(randomCounselor);
    const gifInterval = setInterval(() => {
      setShowCuteGif(true);
      setTimeout(() => setShowCuteGif(false), 5000);
    }, 300000);
    return () => clearInterval(gifInterval);
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      const currentIndex = colors.indexOf(boxColor);
      const nextIndex = (currentIndex + 1) % colors.length;
      setBoxColor(colors[nextIndex]);
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (counselor) {
      const initialMessage = {
        role: "assistant",
        content: `Xin chào con! 👋 ${counselor.prefix} là ${counselor.name}, chuyên gia tư vấn tâm lý học đường. ${counselor.prefix} sẽ lắng nghe và hỗ trợ con với các vấn đề về tâm lý 🧠, học tập 📚, mối quan hệ bạn bè 👥 và gia đình 👨‍👩‍👧‍👦. Con có thể chia sẻ với ${counselor.prefix} những điều đang khiến con băn khoăn nhé! 🌟\n\nTrước khi bắt đầu, con có thể cho ${counselor.prefix} biết tên, lớp và một vài thông tin về bản thân được không? 🎓`,
      };
      setMessages([initialMessage]);
    }
  }, [counselor]);

  const handleFinish = useCallback((message) => {
    setMessages((prev) => [...prev, { role: "assistant", content: message }]);
    setStreamingMessage("");
  }, []);
  const handleStreamResponse = useHandleStreamResponse({
    onChunk: setStreamingMessage,
    onFinish: handleFinish,
  });

  useEffect(() => {
    if (lastMessageRef) {
      lastMessageRef.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, streamingMessage, lastMessageRef]);

  useEffect(() => {
    const handleVisibilityChange = () => {
      setKeyboardVisible(document.visibilityState === "visible");
    };
    document.addEventListener("visibilitychange", handleVisibilityChange);
    return () => {
      document.removeEventListener("visibilitychange", handleVisibilityChange);
    };
  }, []);

  const checkPositiveMessage = (message) => {
    const positiveWords = [
      "tuyệt vời",
      "thú vị",
      "vui vẻ",
      "hạnh phúc",
      "lạc quan",
      "mạnh mẽ",
      "tuyệt đối",
      "vững vàng",
      "tự tin",
      "yên tâm",
      "tích cực",
      "hy vọng",
      "cảm ơn thầy",
      "cảm ơn cô",
      "em rất biết ơn",
      "nhờ thầy",
      "cảm ơn",
      "lời khuyên của thầy",
      "lời khuyên của cô",
      "em cảm thấy tự tin",
      "em rất trân trọng",
      "đáng kính",
      "đáng tin cậy",
      "nhiệt tình",
      "tận tâm",
      "chu đáo",
      "vui tính",
      "sáng suốt",
      "quý trọng",
      "cảm động",
      "khâm phục",
      "hài lòng",
      "ngưỡng mộ",
    ];
    return positiveWords.some((word) => message.toLowerCase().includes(word));
  };

  useEffect(() => {
    const checkInactivity = setInterval(() => {
      if (
        Date.now() - lastMessageTime > 15000 &&
        messages.length > 0 &&
        !showReminder
      ) {
        const response = {
          role: "assistant",
          content: `Con đang cảm thấy như thế nào? Con có điều gì muốn chia sẻ với ${
            counselor?.prefix || "thầy/cô"
          } không? 😊`,
        };
        setMessages((prev) => [...prev, response]);
        setShowReminder(true);
      }
    }, 15000);
    return () => clearInterval(checkInactivity);
  }, [lastMessageTime, messages.length, showReminder]);

  useEffect(() => {
    if (inputMessage) {
      setLastMessageTime(Date.now());
      setShowReminder(false);
    }
  }, [inputMessage]);

  const handleSendMessage = async () => {
    setLastMessageTime(Date.now());
    setShowReminder(false);

    if (!inputMessage.trim()) return;

    const censoredMessage = censorBadWords(inputMessage);
    const newMessage = { role: "user", content: censoredMessage };

    if (
      censoredMessage.toLowerCase().includes("cảm ơn") ||
      censoredMessage.toLowerCase().includes("thầy hạnh")
    ) {
      setShowHearts(true);
      setTimeout(() => setShowHearts(false), 5000);
    }

    setMessages((prev) => [...prev, newMessage]);
    setInputMessage("");

    if (censoredMessage.toLowerCase().includes("danh sách các thầy cô")) {
      const teachersBySubject = {};
      counselors.forEach((teacher) => {
        if (!teachersBySubject[teacher.subject]) {
          teachersBySubject[teacher.subject] = [];
        }
        const displayName = teacher.role
          ? `${teacher.name} (${teacher.role})`
          : teacher.name;
        teachersBySubject[teacher.subject].push(displayName);
      });

      let response =
        "Danh sách các thầy cô giáo tại trường PTDTBT THCS Thu Cúc:\n\n";
      for (const [subject, teachers] of Object.entries(teachersBySubject)) {
        response += `${subject}:\n${teachers.join("\n")}\n\n`;
      }

      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: response },
      ]);
      return;
    }

    const detectedSubject = detectSubject(censoredMessage);
    if (detectedSubject) {
      const subjectTeachers = counselors.filter(
        (c) => c.subject === detectedSubject
      );
      const teacherList = subjectTeachers.map((t) => `${t.name}`).join(", ");
      const response = {
        role: "assistant",
        content:
          detectedSubject === "Tin học"
            ? `Con đang hỏi về môn Tin học 💻. ${counselor.prefix} xin giới thiệu con đến các giáo viên bộ môn: Cô Phạm Thị Hạnh, Thầy Nguyễn Minh Tâm. Con có thể trao đổi trực tiếp với các thầy cô để được hướng dẫn chi tiết nhé! 📚`
            : `Con đang hỏi về môn ${detectedSubject} ${getSubjectEmoji(
                detectedSubject
              )}. ${
                counselor.prefix
              } xin giới thiệu con đến các giáo viên bộ môn: ${teacherList}. Con có thể trao đổi trực tiếp với các thầy cô để được hướng dẫn chi tiết nhé! 📚`,
      };
      setMessages((prev) => [...prev, response]);
      return;
    }

    const creatorInfo = {
      name: "Duy Hạnh",
      phone: "0868640898",
      email: "thcsthucuc@gmail.com",
      school: "PTDTBT THCS Thu Cúc",
      address: "Thu Cúc - Tân Sơn - Phú Thọ",
    };
    const isAskingAboutCreator =
      censoredMessage.toLowerCase().includes("ai tạo") ||
      censoredMessage.toLowerCase().includes("người tạo") ||
      censoredMessage.toLowerCase().includes("thông tin người");

    if (isAskingAboutCreator) {
      const creatorResponse = {
        role: "assistant",
        content: `Phần mềm này được tạo bởi thầy ${creatorInfo.name}. 
                 Bạn có thể liên hệ qua:
                 - Điện thoại: ${creatorInfo.phone}
                 - Email: ${creatorInfo.email}
                 - Địa chỉ: ${creatorInfo.school}, ${creatorInfo.address}`,
      };
      setMessages((prev) => [...prev, creatorResponse]);
      return;
    }

    const teacherInfo = counselors
      .map((c) => `${c.name} - Giáo viên môn ${c.subject}`)
      .join("\n");
    const systemPrompt = `You are ${counselor.name}, a professional school counselor at PTDTBT THCS Thu Cúc (Address: Thu Cúc - Tân Sơn - Phú Thọ, Email: thcsthucuc@gmail.com, Phone: 0868640898). Respond in Vietnamese, use "${counselor.prefix}" to refer to yourself and "con" for the student. When students ask about teachers, provide information from this list:\n${teacherInfo}\n

Important rules:
1. Only respond to questions related to education, learning, student psychology, and school-related topics
2. For non-educational topics, politely decline and redirect to educational matters
3. When students ask about Thầy Duy Công Hạnh, highlight his information in red using HTML tags <span style="color: red">...</span>
4. When students ask for help with homework or solving problems, only provide guidance and suggestions on how to approach the problem. Never solve the problem directly.
5. Encourage critical thinking by asking guiding questions.
6. Help students break down complex problems into smaller steps.
7. Remind students that learning comes from understanding the process, not just getting the answer.
8. If students insist on getting direct answers, politely explain that your role is to help them learn independently.
9. không làm bài tập cho học sinh chỉ hướng dẫn.
10. For subject-specific questions, redirect students to the appropriate subject teachers.
11. When students ask about school leadership, mention that Thầy Đinh Trung Kiên is the principal (Hiệu trưởng) and Thầy Đỗ Ngọc Huỳnh is the vice principal (Hiệu phó).
12. For math equation solving, present steps in a clear, numbered format with explanations for each step.
13. Use LaTeX formatting for mathematical expressions (e.g. \\(2x = 3\\)).
14. Encourage students to verify their answers by checking their work.
15. For non-educational topics, respond with: "Xin lỗi con, ${counselor.prefix} chỉ có thể tư vấn về các vấn đề học tập, tâm lý học đường và giáo dục. Con có thể chia sẻ những khó khăn trong học tập hoặc trường lớp không?"

For other topics, provide counseling for student psychological issues, academic stress, relationships, and personal development. Be empathetic, professional, and supportive. Keep responses brief and concise. Use appropriate emojis occasionally.`;

    const response = await fetch("/integrations/chat-gpt/conversationgpt4", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          { role: "system", content: systemPrompt },
          ...messages,
          newMessage,
        ],
        stream: true,
      }),
    });

    handleStreamResponse(response);
  };

  const handleSpeak = async (text) => {
    if (isSpeaking) return;
    setIsSpeaking(true);
    try {
      const response = await fetch(
        `/integrations/text-to-speech/speech?text=${encodeURIComponent(
          text
        )}&lang=vi`
      );
      const audioBlob = await response.blob();
      const audioUrl = URL.createObjectURL(audioBlob);
      const audio = new Audio(audioUrl);
      audio.onended = () => {
        setIsSpeaking(false);
        URL.revokeObjectURL(audioUrl);
      };
      await audio.play();
    } catch (error) {
      console.error("Error speaking:", error);
      setIsSpeaking(false);
    }
  };

  const handleTranslate = async (text) => {
    setIsTranslating(true);
    const response = await fetch("/integrations/chat-gpt/conversationgpt4", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          {
            role: "system",
            content:
              "You are a translator. Translate the following Vietnamese text to English. Keep the translation natural and conversational.",
          },
          { role: "user", content: text },
        ],
        stream: false,
      }),
    });
    const data = await response.json();
    setIsTranslating(false);
    return data.choices[0].message.content;
  };

  const handleEmotionSelect = (emotion) => {
    const emotionMessage = `${
      emotion.emoji
    } Em đang cảm thấy ${emotion.label.toLowerCase()}`;
    setInputMessage(emotionMessage);
    setShowEmotions(false);
  };
  const formatResponse = (content) => {
    const sections = content.split(/(?=\d+\.\s+\*\*[^*]+\*\*)/);
    return sections
      .map((section, index) => {
        if (index === 0 && !section.match(/^\d+\.\s+\*\*/)) {
          return section;
        }
        const [title, ...details] = section.split("\n");
        const formattedTitle = title.replace(/^\d+\.\s+\*\*([^*]+)\*\*/, "$1");
        return `<div class="mb-4">
        <h3 class="text-lg font-semibold mb-2">${index}. ${formattedTitle}</h3>
        <div class="pl-4">${details.join("\n")}</div>
      </div>`;
      })
      .join("");
  };

  return (
    <div
      className={`fixed inset-0 flex flex-col ${
        isDarkMode
          ? "bg-gray-900"
          : "bg-gradient-to-br from-[#e8f5e9] to-[#e3f2fd]"
      } md:p-4`}
    >
      {showPetals && <div className="cherry-petals" />}
      {showCuteGif && (
        <div className="fixed top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 z-50 animate-bounce">
          <img
            src="/cute-animal.gif"
            alt="Cute animal animation"
            className="w-32 h-32 rounded-full shadow-lg"
          />
        </div>
      )}
      <div
        className={`sticky top-0 z-10 ${
          isDarkMode ? "bg-gray-800/90" : "bg-white/90"
        } backdrop-blur-sm shadow-lg rounded-b-xl`}
      >
        <div className="flex flex-col items-start p-4">
          <div className="flex justify-between items-center w-full">
            <div
              className={`text-sm ${
                isDarkMode ? "text-gray-300" : "text-gray-600"
              } mb-2 font-semibold text-center flex-1`}
            >
              <span className="font-bold">TRƯỜNG PTDTBT THCS THU CÚC</span>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setIsDarkMode(!isDarkMode)}
                className={`${
                  isDarkMode
                    ? "text-yellow-500 hover:text-yellow-400"
                    : "text-gray-600 hover:text-gray-700"
                } transition-colors`}
              >
                <i
                  className={`fas fa-${isDarkMode ? "sun" : "moon"} text-lg`}
                ></i>
              </button>
              <button
                onClick={() => setIsMessagesVisible(!isMessagesVisible)}
                className={`${
                  isDarkMode
                    ? "text-gray-300 hover:text-gray-200"
                    : "text-blue-600 hover:text-blue-700"
                } transition-colors`}
              >
                <i
                  className={`fas fa-${
                    isMessagesVisible ? "eye-slash" : "eye"
                  } text-lg`}
                ></i>
              </button>
              <button
                onClick={() => setShowCreatorInfo(!showCreatorInfo)}
                className={`${
                  isDarkMode
                    ? "text-gray-300 hover:text-gray-200"
                    : "text-blue-600 hover:text-blue-700"
                } transition-colors`}
              >
                <i className="fas fa-info-circle text-lg"></i>
              </button>
            </div>
          </div>
          {showCreatorInfo && (
            <div
              className={`w-full p-3 ${
                isDarkMode ? "bg-gray-800/80" : "bg-white/80"
              } rounded-lg shadow-sm mb-2`}
            >
              <div
                className={`text-sm ${
                  isDarkMode ? "text-gray-300" : "text-gray-900"
                }`}
              >
                <p className="font-semibold">Người tạo: Duy Hạnh</p>
                <p>Liên hệ: 0868640898</p>
              </div>
            </div>
          )}
          {counselor && (
            <div className="flex items-start">
              <div className="relative">
                <img
                  src={counselor.image}
                  alt={counselor.name}
                  className="w-10 h-10 rounded-full mr-3"
                />
                <div className="absolute bottom-0 right-3 w-3 h-3 bg-green-500 rounded-full border-2 border-white"></div>
              </div>
              <div className="font-roboto text-left">
                <div
                  className={`text-lg font-semibold ${
                    isDarkMode ? "text-white" : "text-gray-900"
                  }`}
                  dangerouslySetInnerHTML={{ __html: counselor.name }}
                ></div>
                <div className="text-sm text-[#cc0000]">
                  Tư vấn học tập, tâm lý học đường
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      <div
        className={`flex-1 overflow-y-auto px-4 py-6 pb-24 transition-all duration-300 ${
          isMessagesVisible ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
      >
        <div className="space-y-6 mb-[120px]">
          {messages.map((message, index) => (
            <div
              key={index}
              ref={index === messages.length - 1 ? setLastMessageRef : null}
              className={`flex ${
                message.role === "user" ? "justify-end" : "justify-start"
              } mb-4 animate-fade-in relative`}
            >
              <div
                className={`flex ${
                  message.role === "user" ? "flex-row-reverse" : "flex-row"
                } items-start max-w-[80%] group`}
              >
                <img
                  src={
                    message.role === "user" ? "/student.jpg" : counselor?.image
                  }
                  alt={message.role === "user" ? "Student" : counselor?.name}
                  className="w-6 h-6 rounded-full mx-2 border-2 border-white shadow-md"
                />
                <div
                  className={`relative px-3 py-2 rounded-2xl shadow-sm transition-all text-base ${
                    message.role === "user"
                      ? "bg-gradient-to-r from-blue-500 to-blue-600 text-white"
                      : isDarkMode
                      ? "bg-gray-800 text-gray-200"
                      : "bg-white text-gray-900"
                  } ${
                    !message.role === "user" &&
                    "border border-gray-100 hover:shadow-md"
                  }`}
                >
                  <div
                    dangerouslySetInnerHTML={{
                      __html:
                        message.role === "assistant"
                          ? formatResponse(message.content)
                          : message.content,
                    }}
                  ></div>
                  {message.role === "assistant" && (
                    <button
                      onClick={async () => {
                        if (!message.translatedContent) {
                          const translation = await handleTranslate(
                            message.content
                          );
                          setMessages((prev) =>
                            prev.map((msg, i) =>
                              i === index
                                ? { ...msg, translatedContent: translation }
                                : msg
                            )
                          );
                        } else {
                          setMessages((prev) =>
                            prev.map((msg, i) =>
                              i === index
                                ? { ...msg, translatedContent: undefined }
                                : msg
                            )
                          );
                        }
                      }}
                      className="absolute -bottom-6 right-0 text-sm text-blue-600 hover:text-blue-700"
                      disabled={isTranslating}
                    >
                      {isTranslating
                        ? "Translating..."
                        : message.translatedContent
                        ? "Show Original"
                        : "Translate"}
                    </button>
                  )}
                  {message.translatedContent && (
                    <div
                      className={`mt-2 pt-2 border-t ${
                        isDarkMode
                          ? "border-gray-700 text-gray-400"
                          : "border-gray-200 text-gray-600"
                      }`}
                    >
                      {message.translatedContent}
                    </div>
                  )}
                </div>
              </div>
              {message.role === "user" &&
                (message.content.toLowerCase().includes("cảm ơn") ||
                  message.content.toLowerCase().includes("thầy hạnh")) &&
                showHearts && (
                  <div className="hearts-container">
                    <div className="floating-hearts absolute -top-4 left-1/2 transform -translate-x-1/2 text-xl">
                      ❤️
                    </div>
                    <div className="floating-hearts absolute -top-4 left-1/4 transform -translate-x-1/2 text-xl">
                      ❤️
                    </div>
                    <div className="floating-hearts absolute -top-4 right-1/4 transform translate-x-1/2 text-xl">
                      ❤️
                    </div>
                    <div className="floating-hearts absolute -top-8 left-1/3 transform -translate-x-1/2 text-xl">
                      ❤️
                    </div>
                    <div className="floating-hearts absolute -top-8 right-1/3 transform translate-x-1/2 text-xl">
                      ❤️
                    </div>
                    <div className="floating-hearts absolute -top-6 left-1/2 transform -translate-x-1/2 text-xl">
                      ❤️
                    </div>
                  </div>
                )}
            </div>
          ))}
          {streamingMessage && (
            <div
              ref={setLastMessageRef}
              className="flex justify-start mb-4 animate-fade-in"
            >
              <div className="flex flex-row items-start max-w-[80%]">
                <img
                  src={counselor?.image}
                  alt={counselor?.name}
                  className="w-6 h-6 rounded-full mx-2 border-2 border-white shadow-md"
                />
                <div
                  className={`px-3 py-2 rounded-2xl ${
                    isDarkMode
                      ? "bg-gray-800 text-gray-200"
                      : "bg-gray-100 text-gray-900"
                  } border ${
                    isDarkMode ? "border-gray-700" : "border-gray-200"
                  } text-sm`}
                >
                  <div className="whitespace-pre-wrap">{streamingMessage}</div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {showRating && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-xl shadow-lg max-w-md w-full mx-4">
            <h3 className="text-lg font-semibold mb-4">
              Đánh giá trải nghiệm của bạn
            </h3>
            <div className="flex justify-center gap-2 mb-4">
              {[1, 2, 3, 4, 5].map((rating) => (
                <button
                  key={rating}
                  onClick={() => setUserRating(rating)}
                  className={`text-2xl ${
                    userRating >= rating ? "text-yellow-400" : "text-gray-300"
                  }`}
                >
                  ★
                </button>
              ))}
            </div>
            <p className="text-center text-gray-600 mb-4">
              99% người dùng hài lòng
            </p>
            <div className="flex justify-end gap-2">
              <button
                onClick={() => setShowRating(false)}
                className="px-4 py-2 text-sm text-gray-600 hover:text-gray-700"
              >
                Đóng
              </button>
              <button
                onClick={() => {
                  setShowRating(false);
                  setUserRating(null);
                }}
                className="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700"
              >
                Gửi đánh giá
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="fixed bottom-[60px] left-0 right-0 p-4 bg-transparent transition-all duration-300">
        {showEmotions && (
          <div
            className={`grid grid-cols-4 gap-2 p-3 mb-2 ${
              isDarkMode ? "bg-gray-800/95" : "bg-white/95"
            } backdrop-blur-sm rounded-2xl shadow-lg border ${
              isDarkMode ? "border-gray-700" : "border-gray-100"
            } max-w-4xl mx-auto`}
          >
            {emotions.map((emotion) => (
              <button
                key={emotion.label}
                onClick={() => handleEmotionSelect(emotion)}
                className={`flex flex-col items-center p-2 rounded-lg ${
                  isDarkMode ? "hover:bg-gray-700" : "hover:bg-gray-100"
                } transition-colors`}
              >
                <span className="text-xl md:text-2xl">{emotion.emoji}</span>
                <span
                  className={`text-[10px] md:text-xs mt-1 ${
                    isDarkMode ? "text-gray-300" : "text-gray-600"
                  }`}
                >
                  {emotion.label}
                </span>
              </button>
            ))}
          </div>
        )}
        <div
          className={`flex items-center gap-2 md:gap-3 p-2 md:p-3 ${
            isDarkMode ? "bg-gray-800/95" : "bg-white/95"
          } backdrop-blur-sm rounded-2xl shadow-lg border ${
            isDarkMode ? "border-gray-700" : "border-gray-100"
          } max-w-4xl mx-auto`}
        >
          <button
            onClick={() =>
              handleSpeak(messages[messages.length - 1]?.content || "")
            }
            disabled={isSpeaking}
            className={`p-1.5 md:p-2 rounded-full shadow-sm transition-all hover:shadow-md ${
              isSpeaking ? "bg-blue-300" : "bg-blue-500"
            } text-white`}
          >
            <i className="fas fa-volume-up text-sm md:text-base"></i>
          </button>
          <button
            onClick={() => setShowRating(true)}
            className={`p-1.5 md:p-2 rounded-full shadow-sm transition-all hover:shadow-md ${
              isDarkMode ? "bg-gray-700 text-gray-300" : "bg-gray-200"
            }`}
          >
            <i className="fas fa-star text-sm md:text-base"></i>
          </button>
          <button
            onClick={() => setShowEmotions(!showEmotions)}
            className={`p-1.5 md:p-2 rounded-full shadow-sm transition-all hover:shadow-md ${
              isDarkMode ? "bg-gray-700 text-gray-300" : "bg-gray-200"
            }`}
          >
            <i className="fas fa-smile text-sm md:text-base"></i>
          </button>
          <input
            type="text"
            value={inputMessage}
            onChange={(e) => setInputMessage(e.target.value)}
            onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
            onFocus={() => {
              setKeyboardVisible(true);
              setIsMessagesVisible(true);
            }}
            onBlur={() => setKeyboardVisible(false)}
            placeholder="Nhập tin nhắn..."
            className={`flex-1 p-2 md:p-3 text-sm md:text-base rounded-xl border ${
              isDarkMode
                ? "bg-gray-700 border-gray-600 text-gray-200 placeholder-gray-400"
                : "bg-white/50 border-gray-200 text-gray-900"
            } focus:outline-none focus:border-blue-500 focus:ring-2 focus:ring-blue-200 backdrop-blur-sm shadow-sm`}
          />
          <button
            onClick={handleSendMessage}
            className="p-1.5 md:p-2 rounded-full shadow-sm transition-all hover:shadow-md bg-gradient-to-r from-blue-500 to-blue-600 text-white"
          >
            <i className="fas fa-paper-plane text-sm md:text-base"></i>
          </button>
        </div>
      </div>
      <style jsx global>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fade-in {
          animation: fadeIn 0.3s ease-out forwards;
        }
        @keyframes float {
          0% { transform: translateY(0) translateX(0) rotate(0deg); opacity: 1; }
          25% { transform: translateY(-50px) translateX(${
            Math.random() * 100 - 50
          }px) rotate(90deg); opacity: 0.8; }
          50% { transform: translateY(-100px) translateX(${
            Math.random() * 100 - 50
          }px) rotate(180deg); opacity: 0.6; }
          75% { transform: translateY(-150px) translateX(${
            Math.random() * 100 - 50
          }px) rotate(270deg); opacity: 0.4; }
          100% { transform: translateY(-200px) translateX(${
            Math.random() * 100 - 50
          }px) rotate(360deg); opacity: 0; }
        }
        .cherry-petals {
          position: fixed;
          width: 100vw;
          height: 100vh;
          pointer-events: none;
          z-index: 1000;
        }
        .cherry-petals::before,
        .cherry-petals::after {
          content: '❤️';
          position: absolute;
          font-size: 24px;
          animation: float ${3 + Math.random() * 2}s ease-in-out infinite;
          left: ${Math.random() * 100}%;
          bottom: 0;
        }
        .cherry-petals::after {
          content: '❤️';
          left: ${Math.random() * 100}%;
          animation-delay: ${Math.random() * 2}s;
        }
        @keyframes floatUp {
          0% { transform: translateY(0) scale(1) rotate(0deg); opacity: 1; }
          25% { transform: translateY(-5px) scale(0.9) rotate(${
            Math.random() * 90
          }deg); opacity: 0.9; }
          50% { transform: translateY(-10px) scale(0.8) rotate(${
            Math.random() * 180
          }deg); opacity: 0.7; }
          75% { transform: translateY(-15px) scale(0.7) rotate(${
            Math.random() * 270
          }deg); opacity: 0.5; }
          100% { transform: translateY(-20px) scale(0.5) rotate(${
            Math.random() * 360
          }deg); opacity: 0; }
        }
        .floating-hearts {
          animation: floatUp ${2 + Math.random() * 2}s ease-out forwards;
        }
        @keyframes heartRain {
          0% { transform: translateY(-100vh) translateX(${
            Math.random() * 50 - 25
          }px); opacity: 1; }
          50% { transform: translateY(0) translateX(${
            Math.random() * 100 - 50
          }px); opacity: 0.5; }
          100% { transform: translateY(100vh) translateX(${
            Math.random() * 50 - 25
          }px); opacity: 0; }
        }
        .heart-rain {
          position: fixed;
          top: 0;
          left: 0;
          width: 100%;
          height: 100%;
          pointer-events: none;
          z-index: 1000;
        }
        .heart {
          position: absolute;
          font-size: 24px;
          animation: heartRain ${
            3 + Math.random() * 3
          }s linear infinite;`}</style>
    </div>
  );
}

export default MainComponent;